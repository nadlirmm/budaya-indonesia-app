const config = {
  appId: "com.budaya.app",
  appName: "BudayaIndonesiaApp",
  webDir: "out",
  bundledWebRuntime: false
};

export default config;
